# OpenFDAViz Server Side API

# Building
```sh
$ grunt compress
```
The grunt compress command will build a deployable .zip that can be copied to S3 and deployed using Beanstalk or Cloudformation